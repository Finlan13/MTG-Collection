// Builds website/public/collection.json from output/collection.json.
//
// - copies only an allow-list of public fields (no cost basis, notes, dates)
// - derives colours, types and mana value once, at build time
// - attaches the time prices were last refreshed (output/meta.json)
//
// Runs automatically before `npm run dev` and `npm run build`.

import { mkdir, readFile, stat, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { gzipSync } from "node:zlib";

import { slimCollection } from "../src/lib/derive.js";

const here = path.dirname(fileURLToPath(import.meta.url));
const repoRoot = path.resolve(here, "..", "..");

const inputPath = process.env.COLLECTION_FILE ?? path.join(repoRoot, "output", "collection.json");
const metaPath = path.join(path.dirname(inputPath), "meta.json");
const outputPath = path.resolve(here, "..", "public", "collection.json");

const kb = (bytes) => `${(bytes / 1024).toFixed(0)} KB`;

async function readJson(file, { optional = false } = {}) {
  try {
    return JSON.parse(await readFile(file, "utf8"));
  } catch (error) {
    if (optional && error.code === "ENOENT") return null;
    throw new Error(`Could not read ${file}: ${error.message}`);
  }
}

try {
  const raw = await readJson(inputPath);
  const meta = (await readJson(metaPath, { optional: true })) ?? {};

  const { cards, skipped } = slimCollection(raw);
  if (cards.length === 0) {
    throw new Error("No usable cards found in the collection file.");
  }

  const output = {
    meta: {
      generatedAt: new Date().toISOString(),
      pricesUpdatedAt: meta.prices_updated_at ?? null,
    },
    cards,
  };

  const json = JSON.stringify(output);
  await mkdir(path.dirname(outputPath), { recursive: true });
  await writeFile(outputPath, json);

  const inputSize = (await stat(inputPath)).size;
  console.log(
    `collection.json: ${raw.length} records -> ${cards.length} cards` +
      (skipped ? ` (${skipped} skipped)` : "")
  );
  console.log(
    `  ${kb(inputSize)} source -> ${kb(Buffer.byteLength(json))} published` +
      ` (${kb(gzipSync(json).length)} gzipped)`
  );
  if (!meta.prices_updated_at) {
    console.log("  note: output/meta.json not found; price date will not be shown.");
  }
} catch (error) {
  console.error(`prepare-data failed: ${error.message}`);
  process.exit(1);
}
