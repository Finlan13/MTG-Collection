import { useCallback, useDeferredValue, useEffect, useMemo, useRef, useState } from "react";

import CardModal from "./components/CardModal.jsx";
import CardTile from "./components/CardTile.jsx";
import CartDrawer from "./components/CartDrawer.jsx";
import FilterBar from "./components/FilterBar.jsx";
import Footer from "./components/Footer.jsx";
import Header from "./components/Header.jsx";
import Hero from "./components/Hero.jsx";
import { ArrowUpIcon } from "./components/Icons.jsx";
import { useToast } from "./components/Toasts.jsx";
import { PAGE_SIZE } from "./config.js";
import { useCart } from "./hooks/useCart.js";
import { useCollection } from "./hooks/useCollection.js";
import { FINISH_LABEL, finishesOwned, inCart, inCartTotal, remainingStock } from "./lib/cart.js";
import { DEFAULT_FILTERS, activeFilterCount, filterAndSort } from "./lib/filters.js";
import { formatCount } from "./lib/format.js";

const toggleIn = (list, value) => (list.includes(value) ? list.filter((v) => v !== value) : [...list, value]);

function Skeletons() {
  return (
    <div className="grid" aria-hidden="true">
      {Array.from({ length: 12 }, (_, i) => (
        <div className="tile tile-skeleton" key={i}>
          <div className="tile-art" />
          <div className="tile-body">
            <div className="skel-line" />
            <div className="skel-line short" />
          </div>
        </div>
      ))}
    </div>
  );
}

export default function App() {
  const collection = useCollection();
  const cart = useCart(collection.byId);
  const toast = useToast();

  const [filters, setFilters] = useState(DEFAULT_FILTERS);
  const [visible, setVisible] = useState(PAGE_SIZE);
  const [selectedId, setSelectedId] = useState(null);
  const [cartOpen, setCartOpen] = useState(false);
  const [showTop, setShowTop] = useState(false);
  const [bump, setBump] = useState(0);

  const searchRef = useRef(null);
  const sentinelRef = useRef(null);

  // Typing stays instant; the heavy filter + sort runs at lower priority.
  const deferredFilters = useDeferredValue(filters);
  const results = useMemo(
    () => filterAndSort(collection.cards, deferredFilters),
    [collection.cards, deferredFilters]
  );
  const stale = deferredFilters !== filters;

  useEffect(() => setVisible(PAGE_SIZE), [results]);

  const patchFilters = useCallback((patch) => setFilters((f) => ({ ...f, ...patch })), []);
  const resetFilters = useCallback(() => setFilters(DEFAULT_FILTERS), []);
  const toggleColor = useCallback(
    (color) => setFilters((f) => ({ ...f, colors: toggleIn(f.colors, color) })),
    []
  );

  // Load more cards as the end of the list nears the viewport.
  const hasMore = visible < results.length;
  useEffect(() => {
    const node = sentinelRef.current;
    if (!node || !hasMore) return undefined;
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) setVisible((v) => v + PAGE_SIZE);
      },
      { rootMargin: "900px 0px" }
    );
    observer.observe(node);
    return () => observer.disconnect();
  }, [hasMore, visible]);

  // "/" jumps to search; a back-to-top button appears after scrolling.
  useEffect(() => {
    const onKey = (event) => {
      const tag = event.target.tagName;
      if (event.key === "/" && !["INPUT", "TEXTAREA", "SELECT"].includes(tag) && !event.target.isContentEditable) {
        event.preventDefault();
        searchRef.current?.focus();
      }
    };
    const onScroll = () => setShowTop(window.scrollY > 1400);
    window.addEventListener("keydown", onKey);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      window.removeEventListener("keydown", onKey);
      window.removeEventListener("scroll", onScroll);
    };
  }, []);

  // Pulse the cart badge whenever the number of cards changes.
  const lastCount = useRef(cart.summary.cards);
  useEffect(() => {
    if (cart.summary.cards !== lastCount.current) setBump((n) => n + 1);
    lastCount.current = cart.summary.cards;
  }, [cart.summary.cards]);

  // ----------------------------------------------------------- cart actions

  const addWithFeedback = useCallback(
    (card, finish, qty = 1) => {
      const before = inCart(cart.items, card.id, finish);
      const added = cart.add(card, finish, qty);
      const label = finish === "foil" ? `${card.name} (foil)` : card.name;
      if (added === 0) {
        toast(`Every ${FINISH_LABEL[finish].toLowerCase()} copy of ${card.name} is already in your cart.`);
        return;
      }
      toast(`Added ${added > 1 ? `${added} x ` : ""}${label} to your cart.`, {
        action: { label: "Undo", run: () => cart.setQty(card, finish, before) },
      });
    },
    [cart, toast]
  );

  const quickAdd = useCallback(
    (card) => {
      const open = finishesOwned(card).filter((f) => remainingStock(cart.items, card, f) > 0);
      if (open.length === 0) setCartOpen(true);
      else if (open.length > 1) setSelectedId(card.id); // let the visitor choose a finish
      else addWithFeedback(card, open[0]);
    },
    [cart.items, addWithFeedback]
  );

  const openCard = useCallback((card) => setSelectedId(card.id), []);
  const closeCard = useCallback(() => setSelectedId(null), []);

  const selectedIndex = selectedId ? results.findIndex((c) => c.id === selectedId) : -1;
  const selectedCard = selectedId ? collection.byId.get(selectedId) ?? null : null;

  const stepCard = useCallback(
    (delta) => {
      const next = results[selectedIndex + delta];
      if (next) setSelectedId(next.id);
    },
    [results, selectedIndex]
  );

  const openCartFromModal = useCallback(() => {
    setSelectedId(null);
    setCartOpen(true);
  }, []);

  const openCardFromCart = useCallback((card) => {
    setCartOpen(false);
    setSelectedId(card.id);
  }, []);

  // ------------------------------------------------------------------ render

  const shown = results.slice(0, visible);
  const activeCount = activeFilterCount(filters);

  return (
    <>
      <a className="skip-link" href="#collection">
        Skip to the cards
      </a>

      <Header
        ref={searchRef}
        query={filters.query}
        onQuery={(query) => patchFilters({ query })}
        cartCount={cart.summary.cards}
        onOpenCart={() => setCartOpen(true)}
        bump={bump}
      />

      <main id="top">
        {collection.status === "error" ? (
          <section className="state-panel" role="alert">
            <h1>The collection could not be loaded</h1>
            <p>{collection.error}</p>
            <button type="button" className="btn btn-primary" onClick={collection.retry}>
              Try again
            </button>
          </section>
        ) : (
          <>
            {collection.status === "ready" ? (
              <Hero
                totals={collection.totals}
                meta={collection.meta}
                colors={collection.facets.colors}
                selectedColors={filters.colors}
                onToggleColor={toggleColor}
              />
            ) : (
              <section className="hero hero-loading" aria-busy="true">
                <div className="hero-copy">
                  <h1>The Collection</h1>
                  <p className="hero-lede">Opening the archive...</p>
                </div>
              </section>
            )}

            {collection.status === "ready" && (
              <FilterBar
                filters={filters}
                facets={collection.facets}
                onChange={patchFilters}
                onReset={resetFilters}
                activeCount={activeCount}
              />
            )}

            <section id="collection" className="results" aria-label="Cards" tabIndex={-1}>
              {collection.status === "loading" ? (
                <Skeletons />
              ) : (
                <>
                  <p className="results-count" role="status" aria-live="polite">
                    {results.length === collection.cards.length
                      ? `${formatCount(results.length)} different cards`
                      : `${formatCount(results.length)} of ${formatCount(collection.cards.length)} cards match`}
                  </p>

                  {results.length === 0 ? (
                    <div className="state-panel">
                      <h2>No cards match those filters</h2>
                      <p>Try a different search, or clear the filters to see everything again.</p>
                      <button type="button" className="btn btn-primary" onClick={resetFilters}>
                        Clear filters
                      </button>
                    </div>
                  ) : (
                    <div className={`grid${stale ? " is-stale" : ""}`}>
                      {shown.map((card) => {
                        const owned = card.qty + card.foilQty;
                        const basket = inCartTotal(cart.items, card.id);
                        return (
                          <CardTile
                            key={card.id}
                            card={card}
                            inCartCount={basket}
                            remaining={owned - basket}
                            onOpen={openCard}
                            onAdd={quickAdd}
                          />
                        );
                      })}
                    </div>
                  )}

                  {hasMore && (
                    <div className="more" ref={sentinelRef}>
                      <button type="button" className="btn btn-quiet" onClick={() => setVisible((v) => v + PAGE_SIZE)}>
                        Show more cards ({formatCount(results.length - visible)} left)
                      </button>
                    </div>
                  )}
                </>
              )}
            </section>
          </>
        )}
      </main>

      <Footer meta={collection.meta} />

      {showTop && (
        <button
          type="button"
          className="to-top"
          aria-label="Back to top"
          onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
        >
          <ArrowUpIcon />
        </button>
      )}

      <CardModal
        card={selectedCard}
        position={selectedIndex + 1}
        total={results.length}
        onClose={closeCard}
        onStep={stepCard}
        items={cart.items}
        onAdd={addWithFeedback}
        onOpenCart={openCartFromModal}
      />

      <CartDrawer
        open={cartOpen}
        onClose={() => setCartOpen(false)}
        cart={cart}
        meta={collection.meta}
        onOpenCard={openCardFromCart}
      />
    </>
  );
}
