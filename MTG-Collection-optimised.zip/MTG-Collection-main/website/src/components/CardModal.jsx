import { Fragment, useEffect, useState } from "react";

import { FINISH_LABEL, finishesOwned, inCart, remainingStock, stockFor, unitPrice } from "../lib/cart.js";
import { formatMoney } from "../lib/format.js";
import { CardArt } from "./CardTile.jsx";
import Dialog from "./Dialog.jsx";
import { ChevronIcon, CloseIcon, ExternalIcon, FlipIcon } from "./Icons.jsx";
import ManaCost from "./ManaCost.jsx";
import RarityGem from "./RarityGem.jsx";
import Stepper from "./Stepper.jsx";

/** Scryfall serves the same artwork at several sizes. */
const largeImage = (url) => (url ? url.replace("/normal/", "/large/") : url);

/** Rules text: reminder text in italics, {T}-style tokens as small symbols. */
function RulesText({ text }) {
  return text.split("\n").map((paragraph, i) => (
    <p key={i}>
      {paragraph.split(/(\([^)]*\))/g).map((chunk, j) => {
        const parts = chunk.split(/(\{[^}]+\})/g).map((part, k) =>
          /^\{[^}]+\}$/.test(part) ? <ManaCost key={k} cost={part} inline /> : <Fragment key={k}>{part}</Fragment>
        );
        return j % 2 === 1 ? <em key={j}>{parts}</em> : <Fragment key={j}>{parts}</Fragment>;
      })}
    </p>
  ));
}

function FinishRow({ card, finish, items, onAdd, onOpenCart }) {
  const remaining = remainingStock(items, card, finish);
  const inBasket = inCart(items, card.id, finish);
  const [qty, setQty] = useState(1);
  const price = unitPrice(card, finish);

  // Keep the chosen quantity inside what is still available.
  useEffect(() => {
    setQty((q) => Math.min(Math.max(1, q), Math.max(1, remaining)));
  }, [remaining]);

  const label = `${FINISH_LABEL[finish]} ${card.name}`;

  return (
    <li className="finish-row">
      <div className="finish-main">
        <strong>{FINISH_LABEL[finish]}</strong>
        <span className="finish-price">{price === null ? "Price not available" : `${formatMoney(price)} each`}</span>
      </div>
      <p className="finish-stock">
        {stockFor(card, finish)} owned{inBasket > 0 ? `, ${inBasket} in your cart` : ""}
      </p>
      {remaining > 0 ? (
        <div className="finish-actions">
          <Stepper value={qty} max={remaining} onChange={setQty} label={label} />
          <button
            type="button"
            className="btn btn-primary"
            onClick={() => {
              onAdd(card, finish, qty);
              setQty(1);
            }}
          >
            Add to cart
          </button>
        </div>
      ) : (
        <div className="finish-actions">
          <button type="button" className="btn btn-quiet" onClick={onOpenCart}>
            All in cart. Open cart
          </button>
        </div>
      )}
    </li>
  );
}

export default function CardModal({ card, position, total, onClose, onStep, items, onAdd, onOpenCart }) {
  const open = Boolean(card);

  // Stepping to another card re-mounts the body and drops focus, so listen on
  // the window (only while open) rather than on the dialog element.
  useEffect(() => {
    if (!open) return undefined;
    const onKey = (event) => {
      if (["INPUT", "SELECT", "TEXTAREA"].includes(event.target.tagName)) return;
      if (event.key === "ArrowLeft") onStep(-1);
      if (event.key === "ArrowRight") onStep(1);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onStep]);

  return (
    <Dialog
      open={open}
      onClose={onClose}
      label={card ? `${card.name} details` : "Card details"}
      className="modal"
    >
      {card && (
        <ModalBody
          key={card.id}
          card={card}
          position={position}
          total={total}
          onClose={onClose}
          onStep={onStep}
          items={items}
          onAdd={onAdd}
          onOpenCart={onOpenCart}
        />
      )}
    </Dialog>
  );
}

function ModalBody({ card, position, total, onClose, onStep, items, onAdd, onOpenCart }) {
  const [showBack, setShowBack] = useState(false);
  const [useLarge, setUseLarge] = useState(true);

  const original = showBack ? card.backImage : card.image;
  const src = useLarge ? largeImage(original) : original;
  const finishes = finishesOwned(card);

  return (
    <div className="modal-body">
      <button type="button" className="icon-btn modal-close" onClick={onClose} aria-label="Close card details">
        <CloseIcon />
      </button>

      <div className="modal-art">
        <div className={`modal-art-frame${showBack ? " is-back" : ""}`} data-rarity={card.rarity ?? "none"}>
          <CardArt
            key={src ?? "none"}
            card={card}
            src={src}
            loading="eager"
            onFail={() => useLarge && setUseLarge(false)}
          />
        </div>
        {card.backImage && (
          <button type="button" className="btn btn-quiet flip-btn" onClick={() => setShowBack((v) => !v)}>
            <FlipIcon width={16} height={16} />
            {showBack ? "Show front face" : "Show reverse face"}
          </button>
        )}
      </div>

      <div className="modal-info">
        <p className="modal-set">
          <RarityGem rarity={card.rarity} showLabel />
          <span>
            {card.setName ?? card.set?.toUpperCase()}
            {card.number ? `, #${card.number}` : ""}
          </span>
        </p>
        <h2>{card.name}</h2>
        <div className="modal-cost-row">
          <ManaCost cost={card.manaCost} />
          {card.typeLine && <p className="modal-type">{card.typeLine}</p>}
        </div>

        {card.text && (
          <div className="rules-box">
            <RulesText text={card.text} />
          </div>
        )}
        {card.artist && <p className="modal-artist">Illustrated by {card.artist}</p>}

        <h3 className="modal-heading">In my collection</h3>
        <ul className="finish-list">
          {finishes.map((finish) => (
            <FinishRow key={finish} card={card} finish={finish} items={items} onAdd={onAdd} onOpenCart={onOpenCart} />
          ))}
        </ul>

        <div className="modal-foot">
          {card.url && (
            <a className="link" href={card.url} target="_blank" rel="noopener noreferrer">
              View on Scryfall <ExternalIcon width={14} height={14} />
              <span className="sr-only"> (opens in a new tab)</span>
            </a>
          )}
          {position > 0 && (
          <div className="modal-nav">
            <button
              type="button"
              className="icon-btn"
              onClick={() => onStep(-1)}
              disabled={position <= 1}
              aria-label="Previous card"
            >
              <ChevronIcon direction="left" />
            </button>
            <span>
              {position} of {total}
            </span>
            <button
              type="button"
              className="icon-btn"
              onClick={() => onStep(1)}
              disabled={position >= total}
              aria-label="Next card"
            >
              <ChevronIcon direction="right" />
            </button>
          </div>
          )}
        </div>
      </div>
    </div>
  );
}

