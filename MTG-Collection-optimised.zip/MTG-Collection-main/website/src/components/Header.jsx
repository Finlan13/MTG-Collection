import { forwardRef } from "react";

import { SITE } from "../config.js";
import { CartIcon, SearchIcon, SparkIcon } from "./Icons.jsx";

const Header = forwardRef(function Header({ query, onQuery, cartCount, onOpenCart, bump }, searchRef) {
  return (
    <header className="topbar">
      <div className="topbar-inner">
        <a className="brand" href="#top" aria-label={`${SITE.title}, back to top`}>
          <SparkIcon className="brand-mark" width={22} height={22} />
          <span>{SITE.title}</span>
        </a>

        <div className="search">
          <SearchIcon className="search-icon" />
          <label htmlFor="search" className="sr-only">
            Search cards by name, type or rules text
          </label>
          <input
            id="search"
            ref={searchRef}
            type="search"
            placeholder="Search by name, type or rules text"
            value={query}
            onChange={(event) => onQuery(event.target.value)}
            autoComplete="off"
            spellCheck="false"
          />
          <kbd aria-hidden="true">/</kbd>
        </div>

        <button
          type="button"
          className="cart-btn"
          onClick={onOpenCart}
          aria-label={cartCount > 0 ? `Open cart, ${cartCount} ${cartCount === 1 ? "card" : "cards"}` : "Open cart, empty"}
        >
          <CartIcon />
          <span className="cart-btn-label">Cart</span>
          {cartCount > 0 && (
            <span className="cart-badge" key={bump} aria-hidden="true">
              {cartCount}
            </span>
          )}
        </button>
      </div>
    </header>
  );
});

export default Header;
