import { formatDate } from "../lib/format.js";

export default function Footer({ meta }) {
  const updated = meta?.pricesUpdatedAt ? formatDate(meta.pricesUpdatedAt) : null;
  return (
    <footer className="site-footer">
      <div className="footer-inner">
        <p>
          Card images, rules text and prices come from{" "}
          <a href="https://scryfall.com" target="_blank" rel="noopener noreferrer">
            Scryfall
          </a>
          . Prices are US-dollar market references{updated ? `, last refreshed ${updated}` : ""}. They are not
          an offer of sale, and final pricing is agreed by email.
        </p>
        <p>
          This is an unofficial fan site. Magic: The Gathering is a trademark of Wizards of the Coast LLC,
          and this site is not produced, affiliated with or endorsed by Wizards of the Coast. Portions of
          the materials used are property of Wizards of the Coast. &copy; Wizards of the Coast LLC.
        </p>
      </div>
    </footer>
  );
}
