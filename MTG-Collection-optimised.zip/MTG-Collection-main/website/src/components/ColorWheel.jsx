import { COLOR_NAMES, COLOR_ORDER } from "../lib/derive.js";
import { formatCount } from "../lib/format.js";

// White at the top, then clockwise: the order printed on the colour pie.
const ANGLES = { W: -90, U: -18, B: 54, R: 126, G: 198 };
const RING = 37; // distance of each orb from the centre, in % of the wheel

const point = (angle, radius = RING) => ({
  x: 50 + radius * Math.cos((angle * Math.PI) / 180),
  y: 50 + radius * Math.sin((angle * Math.PI) / 180),
});

const vertices = COLOR_ORDER.map((c) => ({ color: c, ...point(ANGLES[c]) }));

// Neighbouring colours (the pentagon) and opposing colours (the star).
const edges = [];
for (let i = 0; i < 5; i += 1) {
  edges.push({ a: vertices[i], b: vertices[(i + 1) % 5], kind: "ally" });
  edges.push({ a: vertices[i], b: vertices[(i + 2) % 5], kind: "enemy" });
}

/**
 * The five-colour wheel doubles as the colour filter: each orb is a toggle
 * button showing how many cards of that colour are in the collection.
 */
export default function ColorWheel({ selected, counts, onToggle }) {
  const anySelected = selected.length > 0;

  return (
    <div className="wheel" role="group" aria-label="Filter by colour">
      <svg className="wheel-lines" viewBox="0 0 100 100" aria-hidden="true" focusable="false">
        {edges.map((edge, i) => (
          <line
            key={i}
            className={`wheel-line wheel-line-${edge.kind}`}
            x1={edge.a.x}
            y1={edge.a.y}
            x2={edge.b.x}
            y2={edge.b.y}
            pathLength={edge.kind === "ally" ? 1 : undefined}
            style={{ "--i": i }}
          />
        ))}
      </svg>

      {vertices.map((v, i) => {
        const isOn = selected.includes(v.color);
        return (
          <button
            key={v.color}
            type="button"
            className={`orb orb-${v.color.toLowerCase()}${isOn ? " is-on" : ""}${anySelected && !isOn ? " is-dim" : ""}`}
            style={{ left: `${v.x}%`, top: `${v.y}%`, "--i": i }}
            aria-pressed={isOn}
            aria-label={`${COLOR_NAMES[v.color]}, ${formatCount(counts[v.color])} cards`}
            onClick={() => onToggle(v.color)}
          >
            <span className="orb-count">{formatCount(counts[v.color])}</span>
            <span className="orb-name">{COLOR_NAMES[v.color]}</span>
          </button>
        );
      })}

      <button
        type="button"
        className={`orb orb-c orb-center${selected.includes("C") ? " is-on" : ""}${
          anySelected && !selected.includes("C") ? " is-dim" : ""
        }`}
        style={{ "--i": 5 }}
        aria-pressed={selected.includes("C")}
        aria-label={`Colourless, ${formatCount(counts.C)} cards`}
        onClick={() => onToggle("C")}
      >
        <span className="orb-count">{formatCount(counts.C)}</span>
        <span className="orb-name">Colourless</span>
      </button>
    </div>
  );
}
