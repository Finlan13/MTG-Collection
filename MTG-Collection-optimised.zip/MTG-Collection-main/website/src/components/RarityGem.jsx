import { capitalise } from "../lib/format.js";

/** Rarity shown as a small coloured gem, with the word for screen readers. */
export default function RarityGem({ rarity, showLabel = false }) {
  if (!rarity) return null;
  return (
    <span className="gem-wrap">
      <span className={`gem gem-${rarity}`} aria-hidden="true" />
      <span className={showLabel ? "gem-label" : "sr-only"}>{capitalise(rarity)}</span>
    </span>
  );
}
