import { describeManaCost, describeSymbols, parseManaCost } from "../lib/derive.js";

const COLOR_VAR = {
  W: "var(--mana-w)",
  U: "var(--mana-u)",
  B: "var(--mana-b)",
  R: "var(--mana-r)",
  G: "var(--mana-g)",
};

function pipStyle(symbol) {
  const [a, b] = symbol.colors.map((c) => COLOR_VAR[c]);
  if (symbol.kind === "hybrid") {
    // {G/U} is split between two colours; {2/R} between grey and a colour.
    return { "--pip-a": a ?? "var(--mana-n)", "--pip-b": b ?? a ?? "var(--mana-n)" };
  }
  if (a) return { "--pip-a": a, "--pip-b": a };
  return {};
}

/** A mana cost drawn with CSS, so there are no symbol assets to download. */
export default function ManaCost({ cost, className = "", inline = false }) {
  const symbols = parseManaCost(cost);
  if (symbols.length === 0) return null;
  return (
    <span
      className={`mana-cost${inline ? " mana-inline" : ""} ${className}`}
      role="img"
      aria-label={inline ? describeSymbols(cost) : describeManaCost(cost)}
    >
      {symbols.map((symbol, index) => (
        <span
          key={index}
          className={`pip pip-${symbol.kind}${symbol.colors[0] ? ` pip-${symbol.colors[0].toLowerCase()}` : ""}`}
          style={pipStyle(symbol)}
          aria-hidden="true"
        >
          {symbol.label}
        </span>
      ))}
    </span>
  );
}
