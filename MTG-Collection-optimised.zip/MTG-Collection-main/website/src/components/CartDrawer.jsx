import { useEffect, useRef, useState } from "react";

import { LAST_SENT_KEY, ORDER_CONFIG, SEND_COOLDOWN_MS } from "../config.js";
import { FINISH_LABEL } from "../lib/cart.js";
import { formatMoney, plural } from "../lib/format.js";
import {
  LIMITS,
  OrderError,
  buildMailto,
  emailSubject,
  formatCartText,
  isOrderConfigured,
  makeReference,
  sendOrder,
  validateContact,
} from "../lib/order.js";
import { CardArt } from "./CardTile.jsx";
import Dialog from "./Dialog.jsx";
import { CartIcon, CheckIcon, CloseIcon, CopyIcon, TrashIcon } from "./Icons.jsx";
import Stepper from "./Stepper.jsx";
import { useToast } from "./Toasts.jsx";

const canSend = isOrderConfigured(ORDER_CONFIG);

const readLastSent = () => {
  try {
    return Number(localStorage.getItem(LAST_SENT_KEY)) || 0;
  } catch {
    return 0;
  }
};

function Field({ id, label, error, hint, children }) {
  return (
    <div className={`form-field${error ? " has-error" : ""}`}>
      <label htmlFor={id}>{label}</label>
      {children}
      {hint && !error && (
        <p className="form-hint" id={`${id}-hint`}>
          {hint}
        </p>
      )}
      {error && (
        <p className="form-error" id={`${id}-error`}>
          {error}
        </p>
      )}
    </div>
  );
}

export default function CartDrawer({ open, onClose, cart, meta, onOpenCard }) {
  const toast = useToast();
  const { lines, summary } = cart;

  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState("idle"); // idle | sending | sent | error
  const [failure, setFailure] = useState("");
  const [sent, setSent] = useState(null);
  const honeypot = useRef(null);
  const formRef = useRef(null);

  // A finished cart confirmation only lasts until the drawer is closed.
  useEffect(() => {
    if (!open && status === "sent") {
      setStatus("idle");
      setSent(null);
    }
  }, [open, status]);

  const update = (field) => (event) => {
    setForm((f) => ({ ...f, [field]: event.target.value }));
    if (errors[field]) setErrors((e) => ({ ...e, [field]: undefined }));
  };

  // Builds the email text from the current cart and whatever contact details exist.
  const buildOrder = (contact) => {
    const reference = makeReference();
    return {
      reference,
      contact,
      lines,
      summary,
      subject: emailSubject(reference, contact, summary),
      body: formatCartText({
        reference,
        contact,
        lines,
        summary,
        pricesAsOf: meta?.pricesUpdatedAt,
        sentAt: new Date(),
      }),
    };
  };

  const looseContact = () => ({
    name: form.name.trim() || "(name not given)",
    email: form.email.trim() || "(email not given)",
    message: form.message.trim(),
  });

  const copyCart = async () => {
    try {
      await navigator.clipboard.writeText(buildOrder(looseContact()).body);
      toast("Cart copied. Paste it into an email to me.");
    } catch {
      toast("Copying was blocked by your browser. Try the email link instead.", { tone: "error" });
    }
  };

  const mailtoHref = () => {
    if (!ORDER_CONFIG.ownerEmail) return null;
    const order = buildOrder(looseContact());
    return buildMailto(ORDER_CONFIG.ownerEmail, order.subject, order.body);
  };

  const onSubmit = async (event) => {
    event.preventDefault();
    if (status === "sending" || lines.length === 0) return;

    const result = validateContact(form);
    setErrors(result.errors);
    if (!result.ok) {
      const firstInvalid = ["name", "email", "message"].find((f) => result.errors[f]);
      formRef.current?.querySelector(`[name="${firstInvalid}"]`)?.focus();
      return;
    }

    // Bots tend to fill every field. Pretend it worked and send nothing.
    if (honeypot.current?.value) {
      setSent({ reference: makeReference(), email: result.values.email, cards: summary.cards });
      setStatus("sent");
      cart.clear();
      return;
    }

    const waitMs = readLastSent() + SEND_COOLDOWN_MS - Date.now();
    if (waitMs > 0) {
      setFailure(`Please wait ${Math.ceil(waitMs / 1000)} seconds before sending another cart.`);
      setStatus("error");
      return;
    }

    const order = buildOrder(result.values);
    setStatus("sending");
    setFailure("");

    try {
      await sendOrder(ORDER_CONFIG, order);
      try {
        localStorage.setItem(LAST_SENT_KEY, String(Date.now()));
      } catch {
        /* non-essential */
      }
      setSent({ reference: order.reference, email: result.values.email, cards: summary.cards });
      setStatus("sent");
      cart.clear();
      setForm((f) => ({ ...f, message: "" }));
    } catch (error) {
      setFailure(error instanceof OrderError ? error.message : "Something went wrong. Please try again.");
      setStatus("error");
    }
  };

  const needFallback = !canSend || status === "error";
  const mailto = open && lines.length > 0 && needFallback ? mailtoHref() : null;

  const emptyCart = () => {
    const snapshot = cart.items;
    cart.clear();
    toast("Cart emptied.", { action: { label: "Undo", run: () => cart.restore(snapshot) } });
  };

  return (
    <Dialog open={open} onClose={onClose} label="Your cart" className="drawer">
      <div className="drawer-inner">
        <header className="drawer-head">
          <h2>{status === "sent" ? "Cart sent" : "Your cart"}</h2>
          <button type="button" className="icon-btn" onClick={onClose} aria-label="Close cart">
            <CloseIcon />
          </button>
        </header>

        {status === "sent" && sent ? (
          <div className="drawer-scroll sent">
            <span className="sent-mark">
              <CheckIcon width={28} height={28} />
            </span>
            <p className="sent-title">
              {sent.cards} {plural(sent.cards, "card")} sent for review.
            </p>
            <p>
              I&rsquo;ll look it over and reply to <strong>{sent.email}</strong>. Your reference is{" "}
              <strong className="reference">{sent.reference}</strong>.
            </p>
            <button type="button" className="btn btn-primary" onClick={onClose}>
              Keep browsing
            </button>
          </div>
        ) : lines.length === 0 ? (
          <div className="drawer-scroll empty">
            <span className="empty-mark">
              <CartIcon width={30} height={30} />
            </span>
            <p className="empty-title">Your cart is empty.</p>
            <p>Add cards from the collection, then send the list to me for review.</p>
            <button type="button" className="btn btn-primary" onClick={onClose}>
              Browse cards
            </button>
          </div>
        ) : (
          <>
            <div className="drawer-scroll">
              {cart.notice && (
                <p className="notice" role="status">
                  {cart.notice}{" "}
                  <button type="button" className="text-btn" onClick={cart.dismissNotice}>
                    Dismiss
                  </button>
                </p>
              )}

              <ul className="cart-lines">
                {lines.map((line) => (
                  <li className="cart-line" key={line.key}>
                    <button
                      type="button"
                      className="cart-thumb"
                      onClick={() => onOpenCard(line.card)}
                      aria-label={`View details for ${line.card.name}`}
                    >
                      <CardArt card={line.card} />
                    </button>
                    <div className="cart-line-main">
                      <p className="cart-name">{line.card.name}</p>
                      <p className="cart-meta">
                        {FINISH_LABEL[line.finish]}, {line.card.setName ?? line.card.set?.toUpperCase()}
                        {line.card.number ? ` #${line.card.number}` : ""}
                      </p>
                      <p className="cart-price">
                        {line.unit === null ? "Price not available" : `${formatMoney(line.unit)} each`}
                      </p>
                      <div className="cart-controls">
                        <Stepper
                          value={line.qty}
                          max={line.stock}
                          onChange={(qty) => cart.setQty(line.card, line.finish, qty)}
                          label={`${FINISH_LABEL[line.finish]} ${line.card.name}`}
                        />
                        <button
                          type="button"
                          className="icon-btn"
                          onClick={() => cart.remove(line.key)}
                          aria-label={`Remove ${line.card.name} (${FINISH_LABEL[line.finish]}) from cart`}
                        >
                          <TrashIcon width={18} height={18} />
                        </button>
                      </div>
                    </div>
                    <p className="cart-total">{line.total === null ? "n/a" : formatMoney(line.total)}</p>
                  </li>
                ))}
              </ul>

              <form id="cart-form" ref={formRef} noValidate onSubmit={onSubmit} className="order-form">
                <h3>Send it to me</h3>

                <Field id="cf-name" label="Your name" error={errors.name}>
                  <input
                    id="cf-name"
                    name="name"
                    type="text"
                    autoComplete="name"
                    maxLength={LIMITS.name}
                    value={form.name}
                    onChange={update("name")}
                    aria-invalid={Boolean(errors.name)}
                    aria-describedby={errors.name ? "cf-name-error" : undefined}
                  />
                </Field>

                <Field id="cf-email" label="Your email" error={errors.email} hint="I reply to this address.">
                  <input
                    id="cf-email"
                    name="email"
                    type="email"
                    autoComplete="email"
                    inputMode="email"
                    maxLength={LIMITS.email}
                    value={form.email}
                    onChange={update("email")}
                    aria-invalid={Boolean(errors.email)}
                    aria-describedby={errors.email ? "cf-email-error" : "cf-email-hint"}
                  />
                </Field>

                <Field id="cf-message" label="Message (optional)" error={errors.message}>
                  <textarea
                    id="cf-message"
                    name="message"
                    rows={3}
                    maxLength={LIMITS.message}
                    placeholder="Questions, an offer, or a trade you have in mind"
                    value={form.message}
                    onChange={update("message")}
                    aria-invalid={Boolean(errors.message)}
                    aria-describedby={errors.message ? "cf-message-error" : undefined}
                  />
                </Field>

                {/* Hidden from people; automated form-fillers tend to complete it. */}
                <div className="hp" aria-hidden="true">
                  <label>
                    Leave this field empty
                    <input ref={honeypot} type="text" name="website" tabIndex={-1} autoComplete="off" />
                  </label>
                </div>

                {status === "error" && failure && (
                  <div className="notice notice-error" role="alert">
                    <p>{failure}</p>
                  </div>
                )}

                {!canSend && (
                  <p className="notice">
                    Sending from this page is not available right now. Copy your cart and email it to me
                    instead.
                  </p>
                )}

                {needFallback && (
                  <div className="fallbacks">
                    <button type="button" className="btn btn-quiet" onClick={copyCart}>
                      <CopyIcon width={16} height={16} /> Copy cart as text
                    </button>
                    {mailto && (
                      <a className="btn btn-quiet" href={mailto}>
                        Open in email app
                      </a>
                    )}
                  </div>
                )}
              </form>
            </div>

            <footer className="drawer-foot">
              <div className="totals">
                <p>
                  <span>
                    {summary.cards} {plural(summary.cards, "card")}
                  </span>
                  <strong>{formatMoney(summary.value)}</strong>
                </p>
                <p className="totals-note">
                  Reference value in US dollars from Scryfall market prices
                  {summary.unpriced > 0 ? `, not counting ${summary.unpriced} unpriced ${plural(summary.unpriced, "line")}` : ""}.
                  I confirm final pricing when I reply.
                </p>
              </div>
              {canSend && (
                <button type="submit" form="cart-form" className="btn btn-primary btn-wide" disabled={status === "sending"}>
                  {status === "sending" ? "Sending cart..." : status === "error" ? "Try sending again" : "Send cart for review"}
                </button>
              )}
              <button type="button" className="text-btn clear-cart" onClick={emptyCart}>
                Empty cart
              </button>
            </footer>
          </>
        )}
      </div>
    </Dialog>
  );
}
