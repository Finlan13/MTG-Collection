import { memo, useRef, useState } from "react";

import { formatMoney } from "../lib/format.js";
import { CheckIcon, PlusIcon, SparkIcon } from "./Icons.jsx";
import ManaCost from "./ManaCost.jsx";
import RarityGem from "./RarityGem.jsx";

export function CardArt({ card, className = "", src, onFail, loading = "lazy" }) {
  const [failed, setFailed] = useState(false);
  const image = src ?? card.image;

  if (!image || failed) {
    return (
      <div className={`art-fallback ${className}`} role="img" aria-label={`${card.name} (no image available)`}>
        <strong>{card.name}</strong>
        <ManaCost cost={card.manaCost} />
        <span>{card.typeLine}</span>
      </div>
    );
  }

  return (
    <img
      className={`art-img ${className}`}
      src={image}
      width="488"
      height="680"
      alt=""
      loading={loading}
      decoding="async"
      onError={() => {
        setFailed(true);
        onFail?.();
      }}
    />
  );
}

function stockSummary(card) {
  const parts = [];
  if (card.qty > 0) parts.push(`${card.qty} non-foil`);
  if (card.foilQty > 0) parts.push(`${card.foilQty} foil`);
  return parts.join(", ");
}

function CardTile({ card, remaining, inCartCount, onOpen, onAdd }) {
  const artRef = useRef(null);
  const hasFoil = card.foilQty > 0;
  const hasNonFoil = card.qty > 0;
  const soldOut = remaining === 0;

  // Pointer-driven tilt and foil sheen; skipped for touch and reduced motion in CSS.
  const track = (event) => {
    if (event.pointerType !== "mouse") return;
    const el = artRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const x = (event.clientX - rect.left) / rect.width;
    const y = (event.clientY - rect.top) / rect.height;
    el.style.setProperty("--rx", `${((0.5 - y) * 9).toFixed(2)}deg`);
    el.style.setProperty("--ry", `${((x - 0.5) * 9).toFixed(2)}deg`);
    el.style.setProperty("--mx", `${(x * 100).toFixed(1)}%`);
    el.style.setProperty("--my", `${(y * 100).toFixed(1)}%`);
  };

  const release = () => {
    const el = artRef.current;
    if (!el) return;
    el.style.removeProperty("--rx");
    el.style.removeProperty("--ry");
  };

  const mainPrice = hasNonFoil ? card.price : card.foilPrice;

  return (
    <article className={`tile${hasFoil ? " tile-foil" : ""}`} data-rarity={card.rarity ?? "none"}>
      <button
        type="button"
        className="tile-art"
        ref={artRef}
        onPointerMove={track}
        onPointerLeave={release}
        onClick={() => onOpen(card)}
        aria-label={`View details for ${card.name}`}
      >
        <CardArt card={card} />
        {hasFoil && (
          <span className="foil-badge">
            <SparkIcon width={12} height={12} />
            Foil
          </span>
        )}
        {inCartCount > 0 && <span className="incart-badge">{inCartCount} in cart</span>}
      </button>

      <div className="tile-body">
        <h3 className="tile-name">{card.name}</h3>
        <p className="tile-set">
          <RarityGem rarity={card.rarity} />
          <span className="tile-set-name">{card.setName ?? card.set?.toUpperCase()}</span>
          {card.number && <span className="tile-number">#{card.number}</span>}
        </p>

        <div className="tile-price">
          <strong>
            {!hasNonFoil && <SparkIcon className="price-spark" width={12} height={12} />}
            {formatMoney(mainPrice)}
          </strong>
          {hasNonFoil && hasFoil && (
            <span className="tile-price-foil">
              <SparkIcon className="price-spark" width={11} height={11} />
              {formatMoney(card.foilPrice)}
            </span>
          )}
        </div>
        <p className="tile-stock">{stockSummary(card)}</p>

        <button
          type="button"
          className={`add-btn${soldOut ? " is-full" : ""}`}
          onClick={() => onAdd(card)}
          aria-label={
            soldOut ? `All copies of ${card.name} are in your cart. Open cart.` : `Add ${card.name} to cart`
          }
        >
          {soldOut ? <CheckIcon width={16} height={16} /> : <PlusIcon width={16} height={16} />}
          {soldOut ? "All in cart" : "Add to cart"}
        </button>
      </div>
    </article>
  );
}

export default memo(CardTile);
