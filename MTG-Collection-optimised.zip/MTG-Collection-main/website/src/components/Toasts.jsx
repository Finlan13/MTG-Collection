import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";

import { CloseIcon } from "./Icons.jsx";

const ToastContext = createContext(() => {});

export const useToast = () => useContext(ToastContext);

/** Short confirmations, announced politely to screen readers. */
export function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([]);
  const [announcement, setAnnouncement] = useState("");
  const nextId = useRef(1);
  const trayRef = useRef(null);

  const dismiss = useCallback((id) => setToasts((list) => list.filter((t) => t.id !== id)), []);

  const show = useCallback(
    (message, { action, tone = "info", duration = 4500 } = {}) => {
      // Open dialogs make the rest of the page inert, so a button in a toast
      // could not be pressed behind one. Offer actions only when none is open.
      const dialogOpen = Boolean(document.querySelector("dialog[open]"));
      const id = nextId.current++;
      setToasts((list) => [...list.slice(-2), { id, message, tone, action: dialogOpen ? undefined : action }]);
      setAnnouncement(message);
      window.setTimeout(() => dismiss(id), duration);
    },
    [dismiss]
  );

  // The tray lives in the browser's top layer so toasts show above dialogs.
  // Re-opening it moves it back in front of any dialog opened since.
  useEffect(() => {
    const tray = trayRef.current;
    if (!tray?.showPopover) return;
    try {
      if (tray.matches(":popover-open")) tray.hidePopover();
      if (toasts.length > 0) tray.showPopover();
    } catch {
      /* popover API unavailable: toasts still render in the page */
    }
  }, [toasts]);

  const value = useMemo(() => show, [show]);

  return (
    <ToastContext.Provider value={value}>
      {children}
      <div className="sr-only" role="status" aria-live="polite">
        {announcement}
      </div>
      <div ref={trayRef} className="toasts" popover="manual">
        {toasts.map((toast) => (
          <div className={`toast toast-${toast.tone}`} key={toast.id}>
            <span>{toast.message}</span>
            {toast.action && (
              <button
                type="button"
                className="toast-action"
                onClick={() => {
                  toast.action.run();
                  dismiss(toast.id);
                }}
              >
                {toast.action.label}
              </button>
            )}
            <button type="button" className="toast-close" aria-label="Dismiss" onClick={() => dismiss(toast.id)}>
              <CloseIcon width={16} height={16} />
            </button>
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
}
