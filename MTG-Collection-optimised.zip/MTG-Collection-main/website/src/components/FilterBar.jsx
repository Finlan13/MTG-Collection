import { PRICE_BANDS, SORT_OPTIONS } from "../lib/filters.js";
import { RARITY_ORDER, TYPE_ORDER } from "../lib/derive.js";
import { formatCount } from "../lib/format.js";
import RarityGem from "./RarityGem.jsx";

function ChipGroup({ legend, children }) {
  return (
    <fieldset className="chip-group">
      <legend>{legend}</legend>
      <div className="chips">{children}</div>
    </fieldset>
  );
}

function Chip({ pressed, onClick, count, children }) {
  return (
    <button type="button" className={`chip${pressed ? " is-on" : ""}`} aria-pressed={pressed} onClick={onClick}>
      {children}
      <span className="chip-count">{formatCount(count)}</span>
    </button>
  );
}

function Select({ id, label, value, onChange, children }) {
  return (
    <div className="field">
      <label htmlFor={id}>{label}</label>
      <select id={id} value={value} onChange={(event) => onChange(event.target.value)}>
        {children}
      </select>
    </div>
  );
}

const toggle = (list, value) => (list.includes(value) ? list.filter((v) => v !== value) : [...list, value]);

export default function FilterBar({ filters, facets, onChange, onReset, activeCount }) {
  const types = TYPE_ORDER.filter((t) => facets.types[t]);
  const rarities = RARITY_ORDER.filter((r) => facets.rarities[r]);

  return (
    <section className="filters" aria-label="Filter and sort cards">
      <div className="chip-rows">
        <ChipGroup legend="Card type">
          {types.map((type) => (
            <Chip
              key={type}
              pressed={filters.types.includes(type)}
              count={facets.types[type]}
              onClick={() => onChange({ types: toggle(filters.types, type) })}
            >
              {type}
            </Chip>
          ))}
        </ChipGroup>

        <ChipGroup legend="Rarity">
          {rarities.map((rarity) => (
            <Chip
              key={rarity}
              pressed={filters.rarities.includes(rarity)}
              count={facets.rarities[rarity]}
              onClick={() => onChange({ rarities: toggle(filters.rarities, rarity) })}
            >
              <RarityGem rarity={rarity} showLabel />
            </Chip>
          ))}
        </ChipGroup>
      </div>

      <div className="selects">
        <Select id="f-set" label="Set" value={filters.set} onChange={(set) => onChange({ set })}>
          <option value="all">All sets</option>
          {facets.sets.map((set) => (
            <option key={set.name} value={set.name}>
              {set.name} ({set.count})
            </option>
          ))}
        </Select>

        <Select id="f-finish" label="Finish" value={filters.finish} onChange={(finish) => onChange({ finish })}>
          <option value="all">Foil and non-foil</option>
          <option value="foil">Foil only</option>
          <option value="nonfoil">Non-foil only</option>
        </Select>

        <Select id="f-price" label="Price per card" value={filters.price} onChange={(price) => onChange({ price })}>
          {Object.entries(PRICE_BANDS).map(([value, band]) => (
            <option key={value} value={value}>
              {band.label}
            </option>
          ))}
        </Select>

        <Select id="f-sort" label="Sort by" value={filters.sort} onChange={(sort) => onChange({ sort })}>
          {SORT_OPTIONS.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </Select>

        <button type="button" className="text-btn" onClick={onReset} disabled={activeCount === 0 && !filters.query}>
          Clear filters{activeCount > 0 ? ` (${activeCount})` : ""}
        </button>
      </div>
    </section>
  );
}

