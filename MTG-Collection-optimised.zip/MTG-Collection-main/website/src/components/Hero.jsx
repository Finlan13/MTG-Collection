import { formatCount, formatDate, formatMoney } from "../lib/format.js";
import ColorWheel from "./ColorWheel.jsx";

export default function Hero({ totals, meta, colors, selectedColors, onToggleColor }) {
  const updated = meta?.pricesUpdatedAt ? formatDate(meta.pricesUpdatedAt) : "";

  return (
    <section className="hero" aria-labelledby="hero-title">
      <div className="hero-copy">
        <h1 id="hero-title">The Collection</h1>
        <p className="hero-lede">
          Every Magic: The Gathering card I own, with current market prices. Add the ones you want to a
          cart and send it to me. I&rsquo;ll review it and reply by email.
        </p>

        <dl className="facts">
          <div>
            <dt>Cards owned</dt>
            <dd>{formatCount(totals.owned)}</dd>
          </div>
          <div>
            <dt>Different cards</dt>
            <dd>{formatCount(totals.unique)}</dd>
          </div>
          <div>
            <dt>Sets</dt>
            <dd>{formatCount(totals.sets)}</dd>
          </div>
          <div>
            <dt>Reference value</dt>
            <dd>{formatMoney(totals.value)}</dd>
          </div>
        </dl>
        {updated && <p className="hero-updated">Prices from Scryfall, updated {updated}.</p>}
      </div>

      <div className="hero-wheel">
        <ColorWheel selected={selectedColors} counts={colors} onToggle={onToggleColor} />
        <p className="wheel-hint">Choose colours to filter. Cards in any chosen colour are shown.</p>
      </div>
    </section>
  );
}
