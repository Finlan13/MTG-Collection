import { useEffect, useRef } from "react";

/**
 * Thin wrapper over the native <dialog> element. The browser provides the
 * focus trap, Escape handling, inert background and focus restoration; this
 * adds controlled open state and click-outside-to-close.
 */
export default function Dialog({ open, onClose, label, className = "", children, onKeyDown }) {
  const ref = useRef(null);

  useEffect(() => {
    const dialog = ref.current;
    if (!dialog) return;
    if (open && !dialog.open) dialog.showModal();
    if (!open && dialog.open) dialog.close();
  }, [open]);

  return (
    <dialog
      ref={ref}
      className={className}
      aria-label={label}
      onClose={onClose}
      onKeyDown={onKeyDown}
      onMouseDown={(event) => {
        // Only a press on the backdrop itself, never one that started inside.
        if (event.target === ref.current) onClose();
      }}
    >
      {open ? children : null}
    </dialog>
  );
}
