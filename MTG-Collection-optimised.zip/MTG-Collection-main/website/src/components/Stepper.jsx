import { MinusIcon, PlusIcon } from "./Icons.jsx";

/** Quantity control. Buttons only, so the value can never be invalid. */
export default function Stepper({ value, min = 1, max, onChange, label }) {
  return (
    <div className="stepper" role="group" aria-label={label}>
      <button
        type="button"
        onClick={() => onChange(value - 1)}
        disabled={value <= min}
        aria-label={`Decrease quantity of ${label}`}
      >
        <MinusIcon width={16} height={16} />
      </button>
      <output aria-live="polite">{value}</output>
      <button
        type="button"
        onClick={() => onChange(value + 1)}
        disabled={value >= max}
        aria-label={`Increase quantity of ${label}`}
      >
        <PlusIcon width={16} height={16} />
      </button>
    </div>
  );
}
