import { useEffect, useMemo, useState } from "react";

import { buildFacets, prepareCard } from "../lib/filters.js";

/** Loads collection.json once and derives lookups used across the app. */
export function useCollection() {
  const [state, setState] = useState({ status: "loading", cards: [], meta: null, error: null });
  const [attempt, setAttempt] = useState(0);

  useEffect(() => {
    const controller = new AbortController();
    setState((s) => ({ ...s, status: "loading", error: null }));

    fetch(`${import.meta.env.BASE_URL}collection.json`, { signal: controller.signal })
      .then((response) => {
        if (!response.ok) throw new Error(`The collection file returned status ${response.status}.`);
        return response.json();
      })
      .then((data) => {
        if (!data || !Array.isArray(data.cards)) throw new Error("The collection file is not in the expected format.");
        setState({ status: "ready", cards: data.cards.map(prepareCard), meta: data.meta ?? null, error: null });
      })
      .catch((error) => {
        if (error.name === "AbortError") return;
        setState({ status: "error", cards: [], meta: null, error: error.message });
      });

    return () => controller.abort();
  }, [attempt]);

  const derived = useMemo(() => {
    const byId = new Map(state.cards.map((card) => [card.id, card]));
    const facets = buildFacets(state.cards);

    let owned = 0;
    let value = 0;
    for (const card of state.cards) {
      owned += card.qty + card.foilQty;
      value += card.qty * (card.price ?? 0) + card.foilQty * (card.foilPrice ?? 0);
    }
    return { byId, facets, totals: { owned, unique: state.cards.length, value, sets: facets.sets.length } };
  }, [state.cards]);

  return { ...state, ...derived, retry: () => setAttempt((n) => n + 1) };
}
