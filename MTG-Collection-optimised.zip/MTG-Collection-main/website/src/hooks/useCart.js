import { useCallback, useEffect, useMemo, useRef, useState } from "react";

import { CART_STORAGE_KEY } from "../config.js";
import {
  addToCart,
  removeFromCart,
  resolveCart,
  sanitizeStoredCart,
  setCartQty,
  summarize,
} from "../lib/cart.js";

function readStored() {
  try {
    return sanitizeStoredCart(JSON.parse(localStorage.getItem(CART_STORAGE_KEY) ?? "{}"));
  } catch {
    return {};
  }
}

/**
 * Cart state, persisted in localStorage and kept in sync across tabs.
 * Stored entries are checked against the live collection whenever it loads,
 * so a stale cart can never contain cards that are gone or over-stock.
 */
export function useCart(cardsById) {
  const [items, setItems] = useState(readStored);
  const itemsRef = useRef(items);
  const [notice, setNotice] = useState(null);

  const commit = useCallback((next) => {
    itemsRef.current = next;
    setItems(next);
  }, []);

  // Persist.
  useEffect(() => {
    try {
      localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(items));
    } catch {
      /* storage unavailable (private mode, quota): the cart still works in memory */
    }
  }, [items]);

  // Reconcile with the collection once it is available.
  useEffect(() => {
    if (cardsById.size === 0) return;
    const { items: reconciled, dropped, adjusted } = resolveCart(itemsRef.current, cardsById);
    if (dropped || adjusted) {
      commit(reconciled);
      setNotice(
        "Your saved cart was updated because some cards are no longer available in the quantities you chose."
      );
    }
  }, [cardsById, commit]);

  // Keep several open tabs consistent.
  useEffect(() => {
    const onStorage = (event) => {
      if (event.key !== CART_STORAGE_KEY) return;
      try {
        commit(sanitizeStoredCart(JSON.parse(event.newValue ?? "{}")));
      } catch {
        commit({});
      }
    };
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, [commit]);

  const resolved = useMemo(() => resolveCart(items, cardsById), [items, cardsById]);
  const summary = useMemo(() => summarize(resolved.lines), [resolved]);

  const add = useCallback(
    (card, finish, qty = 1) => {
      const result = addToCart(itemsRef.current, card, finish, qty);
      if (result.added > 0) commit(result.items);
      return result.added;
    },
    [commit]
  );

  const setQty = useCallback(
    (card, finish, qty) => commit(setCartQty(itemsRef.current, card, finish, qty)),
    [commit]
  );

  const remove = useCallback((key) => commit(removeFromCart(itemsRef.current, key)), [commit]);
  const clear = useCallback(() => commit({}), [commit]);
  const restore = useCallback((snapshot) => commit(sanitizeStoredCart(snapshot)), [commit]);
  const dismissNotice = useCallback(() => setNotice(null), []);

  return {
    items,
    lines: resolved.lines,
    summary,
    notice,
    dismissNotice,
    add,
    setQty,
    remove,
    clear,
    restore,
  };
}
