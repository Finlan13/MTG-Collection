import React from "react";
import ReactDOM from "react-dom/client";

import "@fontsource-variable/figtree";
import "@fontsource-variable/cormorant-garamond";
import "@fontsource-variable/cormorant-garamond/wght-italic.css";

import App from "./App.jsx";
import { ToastProvider } from "./components/Toasts.jsx";

import "./styles/base.css";
import "./styles/shell.css";
import "./styles/cards.css";
import "./styles/dialogs.css";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <ToastProvider>
      <App />
    </ToastProvider>
  </React.StrictMode>
);
