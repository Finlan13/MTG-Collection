// Site-wide settings. Cart-sending credentials come from build-time
// environment variables (see README); they are public by design.

const env = import.meta.env;

export const SITE = {
  title: "MTG Collection",
  description:
    "Browse my Magic: The Gathering collection, build a cart, and send it to me for review.",
};

export const ORDER_CONFIG = {
  // Web3Forms access key (https://web3forms.com). Preferred.
  web3formsKey: env.VITE_WEB3FORMS_KEY ?? "",
  // Or a Formspree endpoint such as https://formspree.io/f/abcd1234.
  formspreeUrl: env.VITE_FORMSPREE_URL ?? "",
  // Optional. Enables an "Open in email app" fallback; it is visible in the
  // published site, so leave blank if you would rather not expose it.
  ownerEmail: env.VITE_OWNER_EMAIL ?? "",
};

export const CART_STORAGE_KEY = "mtg-collection-cart-v1";
export const LAST_SENT_KEY = "mtg-collection-last-sent";
export const SEND_COOLDOWN_MS = 30_000;
export const PAGE_SIZE = 60;
