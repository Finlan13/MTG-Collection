import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// GitHub Pages serves this project from /MTG-Collection/.
// Override with VITE_BASE=/ when hosting at a domain root.
export default defineConfig({
  plugins: [react()],
  base: process.env.VITE_BASE || "/MTG-Collection/",
  build: {
    target: "es2022",
  },
});
