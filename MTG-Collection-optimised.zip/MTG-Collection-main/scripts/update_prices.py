"""Refresh Scryfall prices for the collection.

- Fetches every card in bulk (75 per request) instead of one at a time.
- Retries rate limits and server errors; a card that cannot be refreshed
  keeps its previous price rather than being dropped.
- Backfills colours, mana value and double-faced-card text that older imports
  did not capture.
- Writes output/meta.json so the website can show when prices were refreshed.
- Exits with an error if nothing could be refreshed, so a failed run is never
  committed as if it had succeeded.
"""

import json
import sys
from datetime import datetime, timezone
from pathlib import Path

from scryfall_common import build_card_record, fetch_collection

CARD_FILE = Path("output/cards.json")
COLLECTION_FILE = Path("output/collection.json")
META_FILE = Path("output/meta.json")

# Scryfall-derived fields that are filled in when missing.
BACKFILL_FIELDS = ("colors", "cmc", "mana_cost", "oracle_text")


def price_or_none(value):
    try:
        return None if value is None else float(value)
    except (TypeError, ValueError):
        return None


def number_or_zero(value):
    try:
        return 0.0 if value is None else float(value)
    except (TypeError, ValueError):
        return 0.0


def backfill(record, scryfall_record):
    """Copy missing Scryfall-derived fields onto a record. Returns True if changed."""
    changed = False
    for field in BACKFILL_FIELDS:
        wanted = scryfall_record.get(field)
        have = record.get(field)
        missing = field not in record or have in (None, "")
        if missing and wanted not in (None, "") and have != wanted:
            record[field] = wanted
            changed = True
    return changed


def apply_updates(collection, master, scryfall_cards):
    """Apply fetched Scryfall cards to the collection and card master in place.

    Returns a dict of counts.
    """
    by_id = {card["id"]: card for card in scryfall_cards if card.get("id")}
    master_by_id = {c.get("scryfall_id"): c for c in master if c.get("scryfall_id")}

    priced = 0
    backfilled = 0

    for record in collection:
        data = by_id.get(record.get("scryfall_id"))
        if data is None:
            continue

        prices = data.get("prices") or {}
        usd = price_or_none(prices.get("usd"))
        usd_foil = price_or_none(prices.get("usd_foil"))

        record["price_usd"] = usd
        record["price_usd_foil"] = usd_foil

        value = number_or_zero(record.get("qty")) * (usd or 0.0)
        value += number_or_zero(record.get("qty_foil")) * (usd_foil or 0.0)
        record["current_value"] = round(value, 2)
        priced += 1

        scryfall_record = build_card_record(data)
        if backfill(record, scryfall_record):
            backfilled += 1

    for scryfall_id, entry in master_by_id.items():
        data = by_id.get(scryfall_id)
        if data is not None:
            backfill(entry, build_card_record(data))

    return {"priced": priced, "backfilled": backfilled}


def write_json(path, payload):
    with open(path, "w", encoding="utf-8") as file:
        json.dump(payload, file, indent=2, ensure_ascii=False, allow_nan=False)


def main(fetch=fetch_collection, now=None):
    print("=" * 60)
    print("MTG COLLECTION - UPDATE PRICES")
    print("=" * 60)

    for path in (CARD_FILE, COLLECTION_FILE):
        if not path.exists():
            raise FileNotFoundError(f"Required file not found: {path}")

    master = json.loads(CARD_FILE.read_text(encoding="utf-8"))
    collection = json.loads(COLLECTION_FILE.read_text(encoding="utf-8"))

    ids = sorted({r["scryfall_id"] for r in collection if r.get("scryfall_id")})
    print(f"\nCards to refresh: {len(ids)}")

    cards, not_found, failed = fetch([{"id": i} for i in ids])

    if not cards:
        print("\nERROR: Scryfall returned no cards. Nothing was changed.")
        return 1

    counts = apply_updates(collection, master, cards)

    write_json(COLLECTION_FILE, collection)
    write_json(CARD_FILE, master)
    write_json(
        META_FILE,
        {"prices_updated_at": (now or datetime.now(timezone.utc)).strftime("%Y-%m-%dT%H:%M:%SZ")},
    )

    print("\n" + "=" * 60)
    print("PRICE UPDATE COMPLETE")
    print("=" * 60)
    print(f"Collection records:   {len(collection)}")
    print(f"Prices refreshed:     {counts['priced']}")
    print(f"Fields backfilled:    {counts['backfilled']}")
    print(f"Not found:            {len(not_found)}")
    print(f"Failed (kept old):    {len(failed)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
