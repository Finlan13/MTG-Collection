"""Shared Scryfall helpers for the import and price-update scripts.

Scryfall's POST /cards/collection endpoint returns up to 75 cards per request,
so a 2,000-card collection needs about 27 calls instead of 2,000.
"""

import time

import requests

API_URL = "https://api.scryfall.com"
HEADERS = {
    "User-Agent": "MTG-Collection/2.0",
    "Accept": "application/json",
    "Content-Type": "application/json",
}

BATCH_SIZE = 75  # Scryfall's maximum identifiers per request
REQUEST_DELAY = 0.1  # Scryfall asks for 50-100 ms between requests
MAX_RETRIES = 4
COLOR_ORDER = "WUBRG"


def chunked(items, size):
    for start in range(0, len(items), size):
        yield items[start:start + size]


def _faces(data):
    faces = data.get("card_faces")
    return faces if isinstance(faces, list) else []


def extract_image_urls(data):
    """Return (front, back) normal-size image URLs for a Scryfall card."""
    front = None
    back = None

    image_uris = data.get("image_uris")
    if isinstance(image_uris, dict):
        front = image_uris.get("normal")

    faces = _faces(data)
    if len(faces) >= 2:
        front_uris = faces[0].get("image_uris") if isinstance(faces[0], dict) else None
        back_uris = faces[1].get("image_uris") if isinstance(faces[1], dict) else None
        if isinstance(front_uris, dict):
            front = front_uris.get("normal") or front
        if isinstance(back_uris, dict):
            back = back_uris.get("normal")

    return front, back


def extract_colors(data):
    """Card colours in WUBRG order, combining both faces of a double-faced card."""
    found = set(data.get("colors") or [])
    for face in _faces(data):
        if isinstance(face, dict):
            found.update(face.get("colors") or [])
    return [c for c in COLOR_ORDER if c in found]


def extract_text_fields(data):
    """mana_cost and oracle_text, falling back to the card faces.

    Double-faced cards have no top-level mana cost or rules text, which left
    them blank (and colourless) in the original data.
    """
    faces = [f for f in _faces(data) if isinstance(f, dict)]

    mana_cost = data.get("mana_cost") or (faces[0].get("mana_cost") if faces else None) or None

    oracle_text = data.get("oracle_text")
    if not oracle_text and faces:
        parts = [f.get("oracle_text") for f in faces if f.get("oracle_text")]
        oracle_text = "\n//\n".join(parts) if parts else None

    return mana_cost, oracle_text or None


def build_card_record(data):
    """Convert a Scryfall card object into the card-master record format."""
    front_image, back_image = extract_image_urls(data)
    mana_cost, oracle_text = extract_text_fields(data)

    return {
        "scryfall_id": data.get("id"),
        "set": data.get("set"),
        "set_name": data.get("set_name"),
        "collector_number": data.get("collector_number"),
        "name": data.get("name"),
        "artist": data.get("artist"),
        "rarity": data.get("rarity"),
        "mana_cost": mana_cost,
        "cmc": data.get("cmc"),
        "colors": extract_colors(data),
        "type_line": data.get("type_line"),
        "oracle_text": oracle_text,
        "image_url": front_image,
        "back_image_url": back_image,
        "scryfall_url": data.get("scryfall_uri"),
    }


def fetch_collection(identifiers, session=None, sleep=time.sleep, log=print):
    """Look up cards in bulk.

    identifiers: dicts such as {"id": "..."} or
                 {"set": "ecl", "collector_number": "1"}.
    Returns (cards, not_found, failed): Scryfall card objects, identifiers
    Scryfall could not match, and identifiers from batches that kept failing.
    Rate limits and server errors are retried with backoff.
    """
    http = session or requests
    cards, not_found, failed = [], [], []
    batches = list(chunked(list(identifiers), BATCH_SIZE))

    for number, batch in enumerate(batches, start=1):
        log(f"  Scryfall batch {number}/{len(batches)} ({len(batch)} cards)")
        result = None

        for attempt in range(MAX_RETRIES):
            try:
                response = http.post(
                    f"{API_URL}/cards/collection",
                    json={"identifiers": batch},
                    headers=HEADERS,
                    timeout=30,
                )
            except requests.RequestException as error:
                log(f"    network error: {error}")
                sleep(2 ** attempt)
                continue

            if response.status_code == 200:
                result = response.json()
                break

            if response.status_code == 429 or response.status_code >= 500:
                try:
                    wait = float(response.headers.get("Retry-After", 2 ** attempt))
                except (TypeError, ValueError):
                    wait = 2 ** attempt
                log(f"    HTTP {response.status_code}, retrying in {wait:.0f}s")
                sleep(wait)
                continue

            log(f"    HTTP {response.status_code}, giving up on this batch")
            break

        if result is None:
            failed.extend(batch)
        else:
            cards.extend(result.get("data", []))
            not_found.extend(result.get("not_found", []))

        sleep(REQUEST_DELAY)

    return cards, not_found, failed
