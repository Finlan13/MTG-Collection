import json
from pathlib import Path

import pandas as pd

from scryfall_common import build_card_record, fetch_collection


# ============================================================
# CONFIGURATION
# ============================================================

INPUT_FILE = Path("data/Collection.xlsx")
CARD_FILE = Path("output/cards.json")
COLLECTION_FILE = Path("output/collection.json")


# ============================================================
# HELPER FUNCTIONS
# ============================================================

def is_blank(value):
    """
    Return True when a value is blank, None or NaN.
    """

    if value is None:
        return True

    try:
        return bool(pd.isna(value))
    except (TypeError, ValueError):
        return False


def number_or_zero(value):
    """
    Convert blank/non-numeric values to zero.
    """

    if is_blank(value):
        return 0.0

    try:
        return float(value)
    except (ValueError, TypeError):
        return 0.0


def number_or_none(value):
    """
    Convert blank/non-numeric values to None.
    """

    if is_blank(value):
        return None

    try:
        return float(value)
    except (ValueError, TypeError):
        return None


def text_or_none(value):
    """
    Convert blank values to None.
    """

    if is_blank(value):
        return None

    text = str(value).strip()

    if text == "":
        return None

    return text


def date_or_none(value):
    """
    Convert Excel dates to ISO format.
    """

    if is_blank(value):
        return None

    if hasattr(value, "isoformat"):
        return value.isoformat()

    return str(value)


def normalise_text(value):
    """
    Normalise text for matching.
    """

    if is_blank(value):
        return ""

    return " ".join(
        str(value).strip().lower().split()
    )


# ============================================================
# LOOK UP PRINTINGS FROM SCRYFALL (BULK)
# ============================================================

def lookup_printings(pairs):
    """
    Look up (set, collector number) pairs in bulk, 75 per request.

    Returns a dict of "set|number" -> card record, plus the number of
    printings Scryfall could not provide.
    """

    identifiers = [
        {"set": set_code, "collector_number": number}
        for set_code, number in pairs
    ]

    found, not_found, failed = fetch_collection(identifiers)

    records = {}

    for data in found:
        key = (
            f"{normalise_text(data.get('set'))}|"
            f"{normalise_text(data.get('collector_number'))}"
        )
        records[key] = build_card_record(data)

    return records, len(not_found) + len(failed)


# ============================================================
# START
# ============================================================

print("=" * 60)
print("MTG COLLECTION - COLLECTION IMPORT")
print("=" * 60)
print()


# ============================================================
# CREATE OUTPUT DIRECTORY
# ============================================================

CARD_FILE.parent.mkdir(
    parents=True,
    exist_ok=True
)


# ============================================================
# LOAD EXISTING CARD MASTER
# ============================================================

if CARD_FILE.exists():

    print("Loading existing card master...")

    with open(
        CARD_FILE,
        "r",
        encoding="utf-8"
    ) as file:

        cards = json.load(file)

else:

    print(
        "No card master found. "
        "A new one will be created."
    )

    cards = []


# ============================================================
# CREATE CARD LOOKUP
# ============================================================

card_index = {}

for card in cards:

    key = (
        f"{normalise_text(card.get('set'))}|"
        f"{normalise_text(card.get('collector_number'))}"
    )

    card_index[key] = card


print(
    f"Existing cards in master: {len(card_index)}"
)

print()


# ============================================================
# READ EXCEL COLLECTION
# ============================================================

print("Reading Excel collection...")

df = pd.read_excel(
    INPUT_FILE
)

df = df.dropna(
    how="all"
)


# ============================================================
# VALIDATE REQUIRED COLUMNS
# ============================================================

required_columns = [
    "ID",
    "Set",
    "CardNo",
    "Name",
    "Qty",
    "Qty (Foil)",
    "AcquisitionDate",
    "PurchasePrice"
]

missing_columns = [
    column
    for column in required_columns
    if column not in df.columns
]

if missing_columns:

    raise ValueError(
        "Missing required columns: "
        + ", ".join(missing_columns)
    )


# ============================================================
# NORMALISE SET AND CARD NUMBER
# ============================================================

df["_set"] = (
    df["Set"]
    .fillna("")
    .astype(str)
    .str.strip()
    .str.lower()
)

df["_card_no"] = (
    df["CardNo"]
    .fillna("")
    .astype(str)
    .str.strip()
)


# ============================================================
# REMOVE INVALID ROWS
# ============================================================

df = df[
    (df["_set"] != "") &
    (df["_card_no"] != "")
]


# ============================================================
# FIND UNIQUE CARDS
# ============================================================

unique_cards = (
    df[
        ["_set", "_card_no"]
    ]
    .drop_duplicates()
)


print(
    f"Collection rows: {len(df)}"
)

print(
    f"Unique card printings: {len(unique_cards)}"
)

print()


# ============================================================
# FIND NEW CARDS
# ============================================================

new_cards = []

existing_cards = 0


for _, row in unique_cards.iterrows():

    key = (
        f"{row['_set']}|"
        f"{row['_card_no']}"
    )

    if key in card_index:

        existing_cards += 1

    else:

        new_cards.append(
            (
                row["_set"],
                row["_card_no"]
            )
        )


print(
    f"Already in card master: {existing_cards}"
)

print(
    f"New cards requiring Scryfall: {len(new_cards)}"
)

print()


# ============================================================
# FIND EXISTING CARDS REQUIRING IMAGE REFRESH
# ============================================================

cards_needing_refresh = []


for _, row in unique_cards.iterrows():

    key = (
        f"{row['_set']}|"
        f"{row['_card_no']}"
    )

    if key not in card_index:
        continue

    existing_card = card_index[key]

    # --------------------------------------------------------
    # Only refresh records that are genuinely incomplete:
    #   - no front image, or
    #   - imported before back_image_url / colors were captured.
    #
    # The previous test also flagged every single-faced card (they
    # never have a back image), so each import re-fetched the whole
    # collection.
    # --------------------------------------------------------

    front_image_missing = not existing_card.get(
        "image_url"
    )

    back_image_missing = (
        "back_image_url" not in existing_card
        or "colors" not in existing_card
    )

    if front_image_missing or back_image_missing:

        cards_needing_refresh.append(
            (
                row["_set"],
                row["_card_no"]
            )
        )


print(
    "Existing cards requiring image refresh: "
    f"{len(cards_needing_refresh)}"
)

print()


# ============================================================
# LOOK UP NEW AND INCOMPLETE CARDS (BULK)
# ============================================================

successful = 0
failed = 0
refreshed = 0
refresh_failed = 0

to_fetch = new_cards + cards_needing_refresh

fetched = {}

if to_fetch:

    print(
        f"Looking up {len(to_fetch)} printings on Scryfall..."
    )

    fetched, _unavailable = lookup_printings(to_fetch)


for set_code, card_number in new_cards:

    key = (
        f"{normalise_text(set_code)}|"
        f"{normalise_text(card_number)}"
    )

    card = fetched.get(key)

    if card is None:

        print(
            f"  NOT FOUND: {set_code.upper()} {card_number}"
        )

        failed += 1

    else:

        card_index[key] = card

        cards.append(card)

        successful += 1


for set_code, card_number in cards_needing_refresh:

    key = (
        f"{normalise_text(set_code)}|"
        f"{normalise_text(card_number)}"
    )

    refreshed_card = fetched.get(key)

    if refreshed_card is None:

        refresh_failed += 1

    else:

        # Update the Scryfall-derived fields on the existing record.
        card_index[key].update(
            refreshed_card
        )

        refreshed += 1


# ============================================================
# SAVE CARD MASTER
# ============================================================

with open(
    CARD_FILE,
    "w",
    encoding="utf-8"
) as file:

    json.dump(
        cards,
        file,
        indent=2,
        ensure_ascii=False,
        allow_nan=False
    )


# ============================================================
# BUILD COLLECTION.JSON
# ============================================================

print()
print("Building collection.json...")
print()


collection = []

matched = 0
unmatched = 0


for _, row in df.iterrows():

    set_code = (
        str(row["Set"])
        .strip()
        .lower()
    )

    card_number = (
        str(row["CardNo"])
        .strip()
    )

    key = (
        f"{normalise_text(set_code)}|"
        f"{normalise_text(card_number)}"
    )

    card = card_index.get(
        key
    )

    if card:

        matched += 1

    else:

        unmatched += 1


    qty = number_or_zero(
        row["Qty"]
    )

    qty_foil = number_or_zero(
        row["Qty (Foil)"]
    )

    purchase_price = number_or_none(
        row["PurchasePrice"]
    )


    # --------------------------------------------------------
    # COST BASIS
    # --------------------------------------------------------

    if purchase_price is not None:

        cost_basis = (
            (qty + qty_foil)
            * purchase_price
        )

    else:

        cost_basis = None


    # --------------------------------------------------------
    # COLLECTION RECORD
    # --------------------------------------------------------

    record = {

        "id":
            text_or_none(
                row["ID"]
            ),

        "set":
            set_code,

        "card_no":
            card_number,

        "name":
            text_or_none(
                row["Name"]
            ),

        "artist":
            (
                text_or_none(
                    row["Artist"]
                )
                if "Artist" in df.columns
                else None
            ),

        "qty":
            qty,

        "qty_foil":
            qty_foil,

        "acquisition_date":
            date_or_none(
                row["AcquisitionDate"]
            ),

        "purchase_price":
            purchase_price,

        "cost_basis":
            cost_basis,

        "notes":
            (
                text_or_none(
                    row["Notes"]
                )
                if "Notes" in df.columns
                else None
            ),

        "scryfall_match":
            bool(card),

        "scryfall_id":
            (
                card.get("scryfall_id")
                if card
                else None
            ),

        "scryfall_name":
            (
                card.get("name")
                if card
                else None
            ),

        "scryfall_set":
            (
                card.get("set")
                if card
                else None
            ),

        "set_name":
            (
                card.get("set_name")
                if card
                else None
            ),

        "collector_number":
            (
                card.get("collector_number")
                if card
                else None
            ),

        "rarity":
            (
                card.get("rarity")
                if card
                else None
            ),

        "mana_cost":
            (
                card.get("mana_cost")
                if card
                else None
            ),

        "type_line":
            (
                card.get("type_line")
                if card
                else None
            ),

        "oracle_text":
            (
                card.get("oracle_text")
                if card
                else None
            ),

        "cmc":
            (
                card.get("cmc")
                if card
                else None
            ),

        "colors":
            (
                card.get("colors")
                if card
                else None
            ),

        "scryfall_artist":
            (
                card.get("artist")
                if card
                else None
            ),

        "image_url":
            (
                card.get("image_url")
                if card
                else None
            ),

        "back_image_url":
            (
                card.get("back_image_url")
                if card
                else None
            ),

        "scryfall_url":
            (
                card.get("scryfall_url")
                if card
                else None
            )
    }


    collection.append(
        record
    )


# ============================================================
# SAVE COLLECTION.JSON
# ============================================================

with open(
    COLLECTION_FILE,
    "w",
    encoding="utf-8"
) as file:

    json.dump(
        collection,
        file,
        indent=2,
        ensure_ascii=False,
        allow_nan=False
    )


# ============================================================
# COUNT DOUBLE-SIDED CARDS
# ============================================================

double_sided_count = sum(
    1
    for card in cards
    if card.get("back_image_url")
)


# ============================================================
# SUMMARY
# ============================================================

print()
print("=" * 60)
print("COLLECTION IMPORT COMPLETE")
print("=" * 60)
print()

print(
    f"Collection rows:             {len(collection)}"
)

print(
    f"Existing cards reused:       {existing_cards}"
)

print(
    f"New cards added:              {successful}"
)

print(
    f"Failed Scryfall calls:        {failed}"
)

print(
    f"Existing cards refreshed:     {refreshed}"
)

print(
    f"Failed refreshes:             {refresh_failed}"
)

print(
    f"Matched collection:           {matched}"
)

print(
    f"Unmatched collection:         {unmatched}"
)

print(
    f"Cards with back images:       {double_sided_count}"
)

print()

print(
    f"Card master: {CARD_FILE}"
)

print(
    f"Collection:  {COLLECTION_FILE}"
)

print()

print(
    "Prices are managed separately "
    "by update_prices.py."
)

print()
