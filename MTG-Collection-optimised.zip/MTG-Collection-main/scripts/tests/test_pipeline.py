import json
import os
import runpy
import shutil
import sys
import tempfile
import unittest
from datetime import datetime, timezone
from pathlib import Path

SCRIPTS = Path(__file__).resolve().parents[1]
REPO = SCRIPTS.parent
sys.path.insert(0, str(SCRIPTS))

import requests  # noqa: E402

import scryfall_common as sc  # noqa: E402
import update_prices  # noqa: E402


class FakeResponse:
    def __init__(self, status, body=None, headers=None):
        self.status_code = status
        self._body = body or {}
        self.headers = headers or {}

    def json(self):
        return self._body


class FakeSession:
    """Plays back a list of responses (or exceptions) and records requests."""

    def __init__(self, script):
        self.script = list(script)
        self.calls = []

    def post(self, url, json=None, **kwargs):
        self.calls.append(json)
        item = self.script.pop(0)
        if isinstance(item, Exception):
            raise item
        return item


DFC = {
    "id": "dfc-1", "set": "dsk", "collector_number": "5", "name": "A // B",
    "colors": None, "cmc": 3.0, "type_line": "Creature // Creature",
    "card_faces": [
        {"mana_cost": "{1}{W}{U}", "colors": ["W", "U"], "oracle_text": "Front text",
         "image_uris": {"normal": "https://x/front.jpg"}},
        {"mana_cost": "", "colors": ["B"], "oracle_text": "Back text",
         "image_uris": {"normal": "https://x/back.jpg"}},
    ],
    "prices": {"usd": "1.50", "usd_foil": None},
}


class CommonTests(unittest.TestCase):
    def test_double_faced_card_gets_faces_text_colours_images(self):
        record = sc.build_card_record(DFC)
        self.assertEqual(record["mana_cost"], "{1}{W}{U}")
        self.assertEqual(record["oracle_text"], "Front text\n//\nBack text")
        self.assertEqual(record["colors"], ["W", "U", "B"])
        self.assertEqual(record["image_url"], "https://x/front.jpg")
        self.assertEqual(record["back_image_url"], "https://x/back.jpg")

    def test_single_faced_card_unchanged(self):
        record = sc.build_card_record({
            "id": "a", "mana_cost": "{G}", "oracle_text": "Hi", "colors": ["G"],
            "image_uris": {"normal": "https://x/a.jpg"}})
        self.assertEqual((record["mana_cost"], record["colors"], record["back_image_url"]),
                         ("{G}", ["G"], None))

    def test_batches_of_75(self):
        ids = [{"id": str(i)} for i in range(160)]
        ok = FakeResponse(200, {"data": [], "not_found": []})
        session = FakeSession([ok, ok, ok])
        sc.fetch_collection(ids, session=session, sleep=lambda s: None, log=lambda m: None)
        self.assertEqual([len(c["identifiers"]) for c in session.calls], [75, 75, 10])

    def test_retries_rate_limit_then_succeeds(self):
        waits = []
        session = FakeSession([
            FakeResponse(429, headers={"Retry-After": "3"}),
            requests.ConnectionError("boom"),
            FakeResponse(200, {"data": [{"id": "x"}], "not_found": [{"id": "y"}]}),
        ])
        cards, nf, failed = sc.fetch_collection(
            [{"id": "x"}, {"id": "y"}], session=session, sleep=waits.append, log=lambda m: None)
        self.assertEqual(len(cards), 1)
        self.assertEqual(len(nf), 1)
        self.assertEqual(failed, [])
        self.assertEqual(waits[0], 3.0)

    def test_gives_up_after_max_retries_and_reports_failures(self):
        session = FakeSession([FakeResponse(500)] * sc.MAX_RETRIES)
        cards, nf, failed = sc.fetch_collection(
            [{"id": "x"}], session=session, sleep=lambda s: None, log=lambda m: None)
        self.assertEqual((cards, failed), ([], [{"id": "x"}]))

    def test_client_error_is_not_retried(self):
        session = FakeSession([FakeResponse(400)])
        sc.fetch_collection([{"id": "x"}], session=session, sleep=lambda s: None, log=lambda m: None)
        self.assertEqual(len(session.calls), 1)


class UpdateTests(unittest.TestCase):
    def test_prices_value_and_backfill(self):
        collection = [{"scryfall_id": "dfc-1", "qty": 2.0, "qty_foil": 1.0,
                       "mana_cost": None, "oracle_text": None, "price_usd": 9.0}]
        master = [{"scryfall_id": "dfc-1", "mana_cost": None}]
        counts = update_prices.apply_updates(collection, master, [DFC])
        record = collection[0]
        self.assertEqual(counts, {"priced": 1, "backfilled": 1})
        self.assertEqual(record["price_usd"], 1.5)
        self.assertIsNone(record["price_usd_foil"])
        self.assertEqual(record["current_value"], 3.0)  # foil has no price: counts as 0
        self.assertEqual(record["colors"], ["W", "U", "B"])
        self.assertEqual(record["mana_cost"], "{1}{W}{U}")
        self.assertEqual(master[0]["colors"], ["W", "U", "B"])

    def test_existing_values_are_not_overwritten_by_backfill(self):
        record = {"mana_cost": "{R}", "colors": ["R"]}
        self.assertFalse(update_prices.backfill(record, {"mana_cost": "{G}", "colors": ["G"]}))
        self.assertEqual(record["mana_cost"], "{R}")

    def test_unrefreshed_cards_keep_old_prices(self):
        collection = [{"scryfall_id": "gone", "qty": 1, "qty_foil": 0, "price_usd": 4.0, "current_value": 4.0}]
        update_prices.apply_updates(collection, [], [DFC])
        self.assertEqual(collection[0]["price_usd"], 4.0)


class EndToEndTests(unittest.TestCase):
    """Runs the real scripts against a copy of the repository's data."""

    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        shutil.copytree(REPO / "output", Path(self.tmp) / "output")
        shutil.copytree(REPO / "data", Path(self.tmp) / "data")
        self.cwd = os.getcwd()
        os.chdir(self.tmp)
        master = json.loads((Path(self.tmp) / "output/cards.json").read_text(encoding="utf-8"))
        self.master_by_set_no = {(c["set"], str(c["collector_number"]).lower()): c for c in master}
        self.master_by_id = {c["scryfall_id"]: c for c in master}

    def tearDown(self):
        os.chdir(self.cwd)
        shutil.rmtree(self.tmp, ignore_errors=True)

    def fake_card(self, m):
        """Rebuild a Scryfall-shaped object from a master record."""
        data = {"id": m["scryfall_id"], "set": m["set"], "set_name": m["set_name"],
                "collector_number": m["collector_number"], "name": m["name"],
                "rarity": m["rarity"], "type_line": m["type_line"], "scryfall_uri": m["scryfall_url"],
                "cmc": 2.0, "prices": {"usd": "1.00", "usd_foil": "2.00"}}
        if m.get("back_image_url"):
            data["card_faces"] = [
                {"mana_cost": "{1}{R}", "colors": ["R"], "oracle_text": "front",
                 "image_uris": {"normal": m["image_url"]}},
                {"mana_cost": "", "colors": ["R"], "oracle_text": "back",
                 "image_uris": {"normal": m["back_image_url"]}}]
        else:
            data.update(mana_cost=m["mana_cost"], oracle_text=m["oracle_text"], colors=["R"],
                        image_uris={"normal": m["image_url"]})
        return data

    def fake_fetch(self, identifiers, **kwargs):
        self.requested = list(identifiers)
        cards, not_found = [], []
        for ident in identifiers:
            m = (self.master_by_id.get(ident["id"]) if "id" in ident
                 else self.master_by_set_no.get((ident["set"], ident["collector_number"].lower())))
            (cards if m else not_found).append(self.fake_card(m) if m else ident)
        return cards, not_found, []

    def test_price_job_updates_everything_and_writes_meta(self):
        when = datetime(2026, 11, 16, 8, 0, tzinfo=timezone.utc)
        code = update_prices.main(fetch=self.fake_fetch, now=when)
        self.assertEqual(code, 0)
        meta = json.loads(Path("output/meta.json").read_text())
        self.assertEqual(meta, {"prices_updated_at": "2026-11-16T08:00:00Z"})
        coll = json.loads(Path("output/collection.json").read_text(encoding="utf-8"))
        matched = [r for r in coll if r.get("scryfall_id")]
        self.assertTrue(all(r["price_usd"] == 1.0 and "colors" in r for r in matched))
        dfc = [r for r in coll if r.get("back_image_url")]
        self.assertTrue(dfc and all(r["mana_cost"] and r["oracle_text"] for r in dfc))
        self.assertEqual(len(self.requested), len({r["scryfall_id"] for r in matched}))

    def test_price_job_fails_loudly_when_scryfall_is_down(self):
        before = Path("output/collection.json").read_bytes()
        code = update_prices.main(fetch=lambda ids: ([], [], list(ids)))
        self.assertEqual(code, 1)
        self.assertEqual(Path("output/collection.json").read_bytes(), before)
        self.assertFalse(Path("output/meta.json").exists())

    def test_importer_no_longer_refetches_the_whole_collection(self):
        sc.fetch_collection = self.fake_fetch
        runpy.run_path(str(SCRIPTS / "import_collection.py"), run_name="__main__")
        # First run: a one-time colour backfill of the 2,046 existing records,
        # plus the single unmatched printing (PRM-2) being retried.
        self.assertEqual(len(self.requested), 2046 + 1)
        coll = json.loads(Path("output/collection.json").read_text(encoding="utf-8"))
        self.assertEqual(len(coll), 2047)

        # Second run: records are complete, so only the still-unmatched printing
        # is retried. The old code re-fetched all ~2,000 cards on every run.
        self.requested = []
        runpy.run_path(str(SCRIPTS / "import_collection.py"), run_name="__main__")
        self.assertEqual(self.requested, [{"set": "prm", "collector_number": "2"}])
        coll = json.loads(Path("output/collection.json").read_text(encoding="utf-8"))
        self.assertTrue(all("colors" in r for r in coll if r["scryfall_match"]))


if __name__ == "__main__":
    unittest.main()
