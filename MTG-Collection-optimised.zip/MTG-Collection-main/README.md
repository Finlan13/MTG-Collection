# MTG Collection

A browsable catalogue of my Magic: The Gathering collection. Visitors can
search and filter, add cards to a cart, and send the cart to me by email for
review. Hosted on GitHub Pages.

## How it fits together

```
data/Collection.xlsx ──► Import MTG Collection (manual) ──┐
                                                           ├─► output/*.json ──► Deploy ──► GitHub Pages
Scryfall API ─────────► Update MTG Prices (daily) ─────────┘
```

| Path | Purpose |
| --- | --- |
| `data/Collection.xlsx` | The spreadsheet I maintain |
| `scripts/import_collection.py` | Matches spreadsheet rows to Scryfall cards (bulk, 75 per request) |
| `scripts/update_prices.py` | Refreshes prices daily and writes `output/meta.json` (price date) |
| `output/` | Generated data committed by the workflows |
| `website/` | The Vite + React site |

The site never reads the spreadsheet-derived file directly. `npm run build`
first runs `website/scripts/prepare-data.mjs`, which copies only an allow-list
of public fields into `website/public/collection.json`, so purchase price,
cost basis, notes and acquisition date are never published.

## Set up the cart email (one time)

GitHub Pages has no server, so the cart is sent through a form-to-email
service. The free tier of [Web3Forms](https://web3forms.com) is enough:

1. Enter your email address on web3forms.com and copy the access key it sends you.
2. In this repository open **Settings > Secrets and variables > Actions >
   Variables** and add a repository variable named `WEB3FORMS_KEY` with that key.
3. Run the **Deploy MTG Collection Website** workflow (or push a change).

The key is public by design: it can only send mail to your address, and
Web3Forms lets you restrict it to your site's domain in their dashboard, which
is worth doing. Each cart arrives as one email with a reference number, the
sender's reply-to address, my card IDs, quantities, finishes and prices.

Alternatives, all optional variables:

| Variable | Effect |
| --- | --- |
| `FORMSPREE_URL` | Use Formspree (`https://formspree.io/f/xxxx`) instead of Web3Forms |
| `OWNER_EMAIL` | Adds an "Open in email app" fallback if sending fails. It becomes visible in the published site, so leave it blank if you don't want it public |

Without any of these the cart still works, but offers "Copy cart as text"
instead of sending.

## Develop

```bash
cd website
npm install
npm run dev      # prepares data, then starts Vite
npm test         # logic tests (node:test)
npm run build    # production build into website/dist
```

For local cart testing put the variables in `website/.env.local`, for example
`VITE_WEB3FORMS_KEY=your-key`.

Pipeline tests (no network needed):

```bash
pip install pandas openpyxl requests
python -m unittest discover -s scripts/tests -v
```

## Updating the collection

Edit `data/Collection.xlsx`, then run **Import MTG Collection** from the
Actions tab. Only new printings (and any records missing data) are looked up.
Prices refresh daily at 20:00 UTC, or run **Update MTG Prices** by hand. Each
successful data run redeploys the site.

## Notes

- Prices are Scryfall's US-dollar market references, shown as `US$`.
  Final pricing is agreed by email.
- Card images, text and prices come from [Scryfall](https://scryfall.com).
  This is unofficial fan content; Magic: The Gathering is a trademark of
  Wizards of the Coast LLC.
